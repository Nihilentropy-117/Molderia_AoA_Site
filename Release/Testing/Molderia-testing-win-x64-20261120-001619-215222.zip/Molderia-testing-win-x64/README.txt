Molderia: Age of Avarice - testing build 20261120-001619-215222 (win-x64)

Extract the entire zip to a writable folder, then run Molderia-Launcher.exe and press Play.
The game and .NET runtime are included; no download or signing key is needed.
Keep testing-release.txt beside the launcher to disable public-release updates.
Install future tester builds into fresh folders. Saves/settings live in saves/;
copy that folder to the next tester build to retain progress. Add mods in user_mods/.
You can also start engine/RuneGame.exe directly.
Linux requires desktop OpenGL/audio libraries. If your extractor drops executable
permissions, run: chmod +x Molderia-Launcher engine/RuneGame
