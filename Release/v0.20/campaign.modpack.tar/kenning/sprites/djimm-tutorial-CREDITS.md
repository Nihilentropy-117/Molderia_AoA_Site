# D’Jimm

East-facing idle pose from the sprite export supplied by the Molderia project owner for use in the game.
