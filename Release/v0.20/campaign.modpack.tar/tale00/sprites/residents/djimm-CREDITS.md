# D’Jimm

Sprite export supplied by the Molderia project owner for use in the game.
