engine.on("onInteract", "tale00:lantern.bed", function(context)
    if context.flags["tale00:complete"] ~= "true" then
        context.setFlag("tale00:complete", "true")
    end
    if context.tales.tale01 then return "tale01" end
    return nil, "You wake up rested at the Crooked Lantern."
end)
