# Brackenstrand illustrated area map

`brackenstrand-area.png`: ChatGPT-generated illustration supplied and approved
by the user for Tale 00, November 19, 2026. Copied from the supplied PNG without
alteration. This artwork is separate from the LPC tiles used by the live map.
