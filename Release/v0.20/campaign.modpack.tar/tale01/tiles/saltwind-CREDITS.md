# Saltwind art credits

`saltwind-ground-*.png`, `saltwind-overhead-*.png`, `saltwind-runes.png` and the sprites in
`../sprites/` are composed by `game/tools/overworld/saltwind.py`. Everything is Liberated Pixel Cup
(LPC) art, used under the licences listed per sheet below; the composed pictures are distributed under
CC-BY-SA 3.0 (the strictest licence among their sources) with these attributions. The slate recolouring
of the cobble, the keep's parapet, banners, spiked barricades, gibbet, pikes, kerbs, bunting, poles,
umbrellas, towels, sandcastles, shells, road-closure barrier, diversion sign, coin-purse sign, milestone, bench, light
glows and sea shading are original project additions.

- **LPC Revised** (https://github.com/ElizaWy/LPC, commit `f07f7f5892e67c932c68f70bb04472f2c64e46bc`), curated by Eliza Wyatt
  (DeathsDarling), OGA-BY 3.0 / CC-BY 3.0. Contributors include Eliza Wyatt, Lanea Zimmerman (Sharm),
  Stephen Challener (Redshrike), Johannes Sjölund (Wulax), BlueCarrot16, BenCreating, Durrani, YuriNikolai
  and Craftpix.net 2D Game Assets.
- **LPC starter kit sheets** from https://github.com/LiberatedPixelCup/RPG_Maker_MZ_LPC_Starter_Kit (commit `c4b2dafe697b6fc7f53aa35d8727afe7542d6e2a`).
- **LPC goblin** from https://github.com/OpenGameArt/LiberatedPixelCup (commit `f61104a1ecc54e7bce54b82ada7d7ba4c41bc524`).

## Sheets used

- `Bluecarrot16/conifers.png` ([LPC] Conifer Trees Pack): bluecarrot16, b_o, Lanea Zimmerman (Sharm), Johann Charlot, Yar, Jetrel, Zabin, Hyptosis, Surt, KnoblePersona; https://opengameart.org/content/lpc-conifer-trees; CC-BY-SA 3.0 / GPL 3.0
- `Casper Nilsson/fence.png` (LPC art entry: wrought-iron fence and gate): Casper Nilsson; https://opengameart.org/content/lpc-cnilsson; CC-BY-SA 3.0 / GPL 3.0
- `Casper Nilsson/water_lilies.png` (LPC art entry: water lilies): Casper Nilsson; https://opengameart.org/content/lpc-cnilsson; CC-BY-SA 3.0 / GPL 3.0
- `Daniel Armstrong (Aka HughSpectrum)/castle_lightsources.png` (Castle light sources (LPC base assets)): Daniel Armstrong (HughSpectrum); https://opengameart.org/content/liberated-pixel-cup-lpc-base-assets-sprites-map-tiles; CC-BY-SA 3.0 / GPL 3.0
- `Daniel Eddeland (Daneeklu)/farming_fishing.png` (LPC farming tilesets: boats, market stall, fish): Daniel Eddeland (Daneeklu); https://opengameart.org/content/lpc-farming-tilesets-magic-animations-and-ui-elements; CC-BY-SA 3.0 / GPL 3.0
- `Sharm/dungeonex.png` ([LPC] Dungeon Elements): Lanea Zimmerman (Sharm); https://opengameart.org/content/lpc-dungeon-elements; CC-BY-SA 3.0 / GPL 3.0
- `sprite/original/Redshrike/goblin/goblin.png` (LPC goblin): Stephen Challener (Redshrike), commissioned by OpenGameArt.org for the Liberated Pixel Cup; https://opengameart.org/content/lpc-goblin; CC-BY-SA 3.0 / GPL 3.0
- `Objects/Furniture/Barrel.png` (Barrel): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/liberated-pixel-cup-lpc-base-assets-sprites-map-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original by Lanea Zimmerman. Recolors by Eliza Wyatt.
- `Objects/Furniture/Crate.png` (Crate): ARTIST(S): Eliza Wyatt (DeathsDarling); LICENSE: OGA-BY 3.0; DETAILS: Original by Eliza Wyatt.
- `Objects/Furniture/Lighting, Outdoors.png` (Lighting, Outdoors): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/lpc-modified-base-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original by Lanea Zimmerman. Recolors by Eliza Wyatt. Inactive version added by Eliza Wyatt.
- `Objects/Small Items/Loose Paper.png` (Loose Paper): ARTIST(S): Eliza Wyatt (DeathsDarling); LICENSE: OGA-BY 3.0; DETAILS: Original by Eliza Wyatt.
- `Objects/Small Items/Skeletons A.png` (Skeletons): ARTIST(S): Lanea Zimmerman (Sharm); SOURCE: https://opengameart.org/content/lpc-dungeon-elements; LICENSE: OGA-BY 3.0; DETAILS: Original by Lanea Zimmerman. Recolored by Eliza Wyatt.
- `Structure/Bridges/Wood Bridge A - No Rails.png` (Wood Bridge A (rails, no rails)): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/liberated-pixel-cup-lpc-base-assets-sprites-map-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original by Lanea Zimmerman. Reworked for tiling by Eliza Wyatt. Recolors by Eliza Wyatt.
- `Structure/Doors/32x64px Doors/15 Panel Door A.png` (12-Panel Door, 15-Panel Door): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/lpc-animated-doors; LICENSE: OGA-BY 3.0; DETAILS: Original design and animation by Lanea Zimmerman. Converted to 15 panel door by Eliza Wyatt. Recolors by Eliza Wyatt.
- `Structure/Pillars/Stone Pillar A.png` (Stone Pillar A): ARTIST(S): Lanea Zimmerman (aka Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/lpc-interior-castle-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original by Lanea Zimmerman. Variations and recolors by Eliza Wyatt.
- `Structure/Roofing/Hipped Shingle Roof A.png` (Hipped Shingle Roof A): ARTIST(S): Lanea Zimmerman (aka Sharm), Eliza Wyatt; SOURCE: https://opengameart.org/content/liberated-pixel-cup-lpc-base-assets-sprites-map-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original by Lanea Zimmerman. Expanded for tiling, alternative roof slants, and recolors by Eliza Wyatt.
- `Structure/Signs/Sign Backgrounds A.png` (Sign Backgrounds A): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/liberated-pixel-cup-lpc-base-assets-sprites-map-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original by Lanea Zimmerman. Recolors by Eliza Wyatt.
- `Structure/Walls/Jagged Stone Walls.png` (Jagged Stone Walls): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/lpc-interior-castle-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original by Lanea Zimmerman. Recolors by Eliza Wyatt.
- `Structure/Walls/Siding, Plain.png` (Siding, Plain): ARTIST(S): Eliza Wyatt (DeathsDarling); LICENSE: OGA-BY 3.0; DETAILS: Original by Eliza Wyatt.
- `Structure/Windows/Stone Windows A.png` (Stone Windows A): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/lpc-interior-castle-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original by Lanea Zimmerman. Blue and yellow glow and emission map by Eliza Wyatt. Recolors by Eliza Wyatt.
- `Terrain/Rocks, Grasslands.png` (Rocks): ARTIST(S): Eliza Wyatt (DeathsDarling); LICENSE: OGA-BY 3.0; DETAILS: Original by Eliza Wyatt.
- `Terrain/flowers.png` (Flowers): ARTIST(S): Lanea Zimmerman (Sharm), Hyptosis, Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/lpc-interior-castle-tiles; SOURCE: https://opengameart.org/content/lots-of-free-2d-tiles-and-sprites-by-hyptosis; LICENSE: OGA-BY 3.0; DETAILS:; Row 1: Rose bush CC0 by BlueCarrot16, edited and recolored by Eliza Wyatt. Non-flowering version by Eliza Wyatt.; Row 2: Small rose bush, derived from the large one by Eliza Wyatt.; Row 3: Flowers by Sharm, recolored by Eliza Wyatt. Non-flowering version by Eliza Wyatt.; Row 4 & 5: Flowers by Hyptosis, edited and recolored by Eliza Wyatt.
- `Terrain/mushrooms.png` (Mushrooms): ARTIST(S): Eliza Wyatt (DeathsDarling), Hyptosis; SOURCE: https://opengameart.org/content/lots-of-free-2d-tiles-and-sprites-by-hyptosis; LICENSE: OGA-BY 3.0; DETAILS: Original large pointed mushroom by Hyptosis, edited and recolored by Eliza Wyatt. All others are original art by Eliza Wyatt.
- `Terrain/plants_summer.png` (Plants (all seasons)): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling), Hyptosis; SOURCE: https://opengameart.org/content/lots-of-free-2d-tiles-and-sprites-by-hyptosis; LICENSE: OGA-BY 3.0; DETAILS: Tropical bush, small tree, shrub, and first tall grasses by Hyptosis. All other plants by Eliza Wyatt. Edited, recolored, and animated by Eliza Wyatt.
- `Terrain/terrain_summer.png` (Terrain (all seasons)): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/liberated-pixel-cup-lpc-base-assets-sprites-map-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original grass, dirt, and shallows by Lanea Zimmerman. Edited, animated, and recolored by Eliza Wyatt.
- `Terrain/trees_summer.png` (Trees (all seasons)): ARTIST(S): Lanea Zimmerman (Sharm), Eliza Wyatt (DeathsDarling); SOURCE: https://opengameart.org/content/liberated-pixel-cup-lpc-base-assets-sprites-map-tiles; LICENSE: OGA-BY 3.0; DETAILS: Original trees by Lanea Zimmerman. Leafless tree and thick trunk by Eliza Wyatt. Reconfigured and recolored by Eliza Wyatt.
