# Main menu assets

## Illustration

`sprites/title-beach.jpg`: D’Jimm’s Beachside Drawing Tablet, generated for Gray Lott
in this project, November 2026. The approved composition includes the blank slate
at his hip. Converted from the approved PNG to high-quality JPEG for packaging.

## Fonts — SIL Open Font License 1.1

- Cinzel by Natanael Gama: https://github.com/google/fonts/tree/main/ofl/cinzel
- Alegreya by Juan Pablo del Peral / Huerta Tipográfica:
  https://github.com/google/fonts/tree/main/ofl/alegreya

Redistributed license and copyright notices: `fonts/cinzel-OFL.txt` and
`fonts/alegreya-OFL.txt`. The bundled fonts are static instances of the upstream
variable fonts, weight 600 for Cinzel and 500 for Alegreya. FontTools generated
these instances; no glyphs were redesigned. Both licenses allow game embedding
and redistribution. Existing DejaVu fonts continue to serve gameplay text.

## Coastal ambience — CC0 1.0

`audio/coast.wav` is a 44-second mono 24 kHz, 16-bit PCM loop mixed from:

- **Beach Ocean Waves**, jasinski, submitted by qubodup:
  https://opengameart.org/content/beach-ocean-waves
  Original recording: https://freesound.org/people/jasinski/sounds/18363/
  Files: `wave_01_cc0-18363__jasinski__alkaibeach.flac`,
  `wave_02_cc0-18363__jasinski__alkaibeach.flac`,
  `wave_03_cc0-18363__jasinski__alkaibeach.flac`.
- **Solo Seagull Sound Effects**, submitted by Rango Mango:
  https://opengameart.org/content/solo-seagull-sound-effects
  Files: `Seagull Ambient 1.wav`, `Seagull Ambient 2.wav`.
  The publisher states permission to share and use commercially without attribution.

Both source pages label these assets CC0. License:
https://creativecommons.org/publicdomain/zero/1.0/

Edits: resampled to mono 24 kHz, surf clips crossfaded, circular loop seam blended,
levels reduced, two gull calls faded and mixed at 7 and 25 seconds. No music or
third-party streaming service is required. Credits are retained voluntarily.

## Tile world — CC0 1.0

Kenney **Tiny Town** (130 tiles, 16×16): https://kenney.nl/assets/tiny-town

Distributed under CC0: https://creativecommons.org/publicdomain/zero/1.0/
Original license notice: `core/tiles/LICENSE.txt` and each bundled pack's `tiles/LICENSE.txt`.

Each package's `tiles/town.png` arranges the unmodified numbered tiles into a 16-column atlas,
IDs 0–129. They render at 2× (32×32 display pixels). Companion swatches 130–135
(water, sand, wood floor, stone floor, dark fill, carpet) are original project
artwork, also dedicated to CC0. Character placeholders remain project code art.

The asset download mirror is https://opengameart.org/content/tiny-town.

## Tale 00 interiors — LPC Revised, OGA-BY 3.0

The seventeen Tale 00 interiors (`modpacks/campaign/tale00/interiors/`) are composed from
**LPC Revised** (https://github.com/ElizaWy/LPC), curated by Eliza Wyatt (DeathsDarling), with art by
Eliza Wyatt, Lanea Zimmerman (Sharm), BlueCarrot16, Richard Kettering (Jetrel), YuriNikolai and the
other contributors named in the collection. Licence: OGA-BY 3.0
(https://opengameart.org/content/oga-by-30-faq). Per-sheet artists, sources and details:
`modpacks/campaign/tale00/interiors/CREDITS.md`. Rebuild with `game/tools/interiors/rooms.py`.

## Tale 00 overworld — LPC Revised, OGA-BY 3.0

Brackenstrand's tilesets (`modpacks/campaign/tale00/tiles/brackenstrand-*.png`) and its signposts
(`modpacks/campaign/tale00/sprites/town/`) are composed from the same **LPC Revised** collection
(terrain, trees, plants, walls, roofing, doors, windows, signs, fences, bridges and street furniture).
Licence: OGA-BY 3.0. Per-sheet artists, sources and details:
`modpacks/campaign/tale00/tiles/brackenstrand-CREDITS.md`. Rebuild with `game/tools/overworld/town.py`.

## Tale 00 residents — Universal LPC Spritesheet Character Generator

The twenty-one resident sheets in `modpacks/campaign/tale00/sprites/residents/` are composited
from Universal LPC layers (https://github.com/LiberatedPixelCup/Universal-LPC-Spritesheet-Character-Generator)
by bluecarrot16, Benjamin K. Smith (BenCreating), Eliza Wyatt (ElizaWy), JaidynReiman, Johannes
Sjölund (wulax), Stephen Challener (Redshrike), Matthew Krohn (makrohn), Nila122 and many others.
Each layer is offered under OGA-BY 3.0 and/or CC-BY-SA 3.0 (plus GPL alternatives); the
composites are distributed under CC-BY-SA 3.0. Every layer's authors, licences and source URLs
are listed per resident in `modpacks/campaign/tale00/sprites/residents/CREDITS.md`. Rebuild with
`game/tools/npcs/build_npcs.py`. D’Jimm and Stevedor are not part of this set.

`modpacks/campaign/tale00/audio/breckenridge-theme.ogg` (shipped inside the Tale 00 mod) is **Pixel Drift – Pixel Dreams** by **thatlofishow**,
used under the [Pixabay Content License](https://pixabay.com/service/license-summary/).
[Original track](https://pixabay.com/music/upbeat-pixel-drift-pixel-dreams-313460/).

## Tale 01 Saltwind Road — LPC Revised and LPC entries, CC-BY-SA 3.0

The Saltwind Road tilesets (`modpacks/campaign/tale01/tiles/saltwind-*.png`) and sprites
(`modpacks/campaign/tale01/sprites/`) are composed by `game/tools/overworld/saltwind.py` from
**LPC Revised** (https://github.com/ElizaWy/LPC, OGA-BY 3.0) and these Liberated Pixel Cup works:
Lanea Zimmerman (Sharm), *[LPC] Dungeon Elements*; Daniel Armstrong (HughSpectrum), castle light
sources; Casper Nilsson, wrought-iron fence, gate and water lilies; bluecarrot16, b_o, Sharm and
others, *[LPC] Conifer Trees Pack*; Daniel Eddeland (Daneeklu), boats and market stall from the LPC
farming tilesets; and Stephen Challener (Redshrike), the LPC goblin used for the toll guards. These are
CC-BY-SA 3.0 / GPL 3.0, so the composed Saltwind art is distributed under CC-BY-SA 3.0. Pinned sources
are fetched by the molderia-art skill's `fetch_sources.sh`. Per-sheet artists, sources and licences:
`modpacks/campaign/tale01/tiles/saltwind-CREDITS.md`.

## Battle presentation

The Kenning package's `sprites/duel-arena.jpg` (`game/modpacks/campaign/kenning/`)
depicts a moonlit coastal cloister. It was generated
for Gray Lott’s Molderia project in November 2026 and compressed as JPEG for
shipping. The Rune Warden and GTF Spellpunk Enforcer profiles were generated
for the same project. Credits accompany each sprite in its boss package.
Stevedor uses the east-facing frame of the original player sheet.

## Dialogue portraits

`portraits/djimm.png` (Tales 00 and 01) uses D’Jimm artwork supplied by Gray Lott,
resized to 256 × 256 for the dialogue interface.


## D’Jimm’s character sprite

The D’Jimm sprite export was supplied by the Molderia project owner. Tales 00 and 01 use
a 64 × 64 frame atlas that preserves the original pixel scale of the eight idle
directions and four cardinal walk cycles. Kenning’s tutorial uses the original east-facing idle pose.

## Tale 00 illustrated area map

`game/modpacks/campaign/tale00/maps/brackenstrand-area.png`: ChatGPT-generated
illustration supplied by the user for this project on November 19, 2026.
Package-local provenance: `tale00/maps/CREDITS.md`.
