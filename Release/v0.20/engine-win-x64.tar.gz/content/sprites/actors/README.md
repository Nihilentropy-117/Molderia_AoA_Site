# Player art: Stevedor Amanuensis

New character sheets use **32×32 frames** at native world scale. See the
[display and art standard](../../../../docs/handbook/design/display-standard.md)
for direction rows, anchors and metadata. The 64×64 export described below is
existing art retained for compatibility; importing it does not convert it into
a native 32px replacement. Always write explicit frame dimensions in metadata.

The default player uses the user-supplied `Stevedor_Amanuensis_is_a_young.zip`
export: eight standing poses and six walking frames per direction. Each cell is
64×64. Rows run south, southeast, east, northeast, north, northwest, west,
southwest. Column zero is the standing pose; columns one through six are walking.
The walking export's 16px transparent padding was removed without resampling or
moving the art within its original canvas. Combat draws the east standing pose.

To rebuild from that export (Pillow required):

```sh
python3 game/tools/import_stevedor.py /path/to/Stevedor_Amanuensis_is_a_young.zip
```

Sprite metadata's optional `walk_start` is the zero-based first walking column;
walking loops from there through `frames - 1`. It defaults to zero for existing
sheets. Idle uses the first `idle_frames` columns (one by default). The shipped
player uses `frames: 7`, `idle_frames: 1`, `walk_start: 1`, and `fps: 8`.
Map-provided `player_sprite` overrides continue to work as before.

