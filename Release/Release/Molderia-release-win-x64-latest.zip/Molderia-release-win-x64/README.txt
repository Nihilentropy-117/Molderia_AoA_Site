Molderia: Age of Avarice v0.20 (win-x64)

Extract the entire ZIP to a writable folder and run Molderia-Launcher.exe, then press Play.
The game and .NET runtime are included. Public updates are enabled.
Keep saves/ when moving to a newer build. Add your mods in user_mods/.
Linux requires desktop OpenGL/audio libraries. If needed, run:
chmod +x Molderia-Launcher engine/RuneGame
